import React, { useState } from 'react';
import axios from 'axios';

function AdminPanel() {
  const [username,setUsername]=useState('');
  const [password,setPassword]=useState('');
  const [projectTitle,setProjectTitle]=useState('');
  const [projectDesc,setProjectDesc]=useState('');
  const [image,setImage]=useState(null);

  const login=async e=>{
    e.preventDefault();
    await axios.post('http://localhost:5000/admin/login',{username,password},{withCredentials:true})
      .then(()=>alert('تم تسجيل الدخول'));
  }

  const addProject=async e=>{
    e.preventDefault();
    const formData=new FormData();
    formData.append('title',projectTitle);
    formData.append('description',projectDesc);
    formData.append('image',image);
    await axios.post('http://localhost:5000/admin/add-project',formData,{withCredentials:true})
      .then(()=>alert('تم إضافة المشروع'));
  }

  return (
    <div>
      <h1>لوحة التحكم</h1>
      <form onSubmit={login}>
        <input placeholder="اسم المستخدم" value={username} onChange={e=>setUsername(e.target.value)} required/>
        <input type="password" placeholder="كلمة السر" value={password} onChange={e=>setPassword(e.target.value)} required/>
        <button>دخول</button>
      </form>

      <h2>إضافة مشروع جديد</h2>
      <form onSubmit={addProject}>
        <input placeholder="عنوان المشروع" value={projectTitle} onChange={e=>setProjectTitle(e.target.value)} required/>
        <textarea placeholder="وصف المشروع" value={projectDesc} onChange={e=>setProjectDesc(e.target.value)} required/>
        <input type="file" onChange={e=>setImage(e.target.files[0])}/>
        <button type="submit">إضافة</button>
      </form>
    </div>
  );
}

export default AdminPanel;
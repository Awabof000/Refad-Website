import React from 'react';

function Hero() {
  return (
    <section className="hero">
      <h1>منظمة رفاد للتنمية الإنسانية</h1>
      <p>نحن نعمل على دعم المجتمعات الضعيفة وتحسين حياة الأفراد.</p>
    </section>
  );
}

export default Hero;
import React, { useState } from 'react';
import axios from 'axios';

function Donations() {
  const [name,setName]=useState('');
  const [amount,setAmount]=useState('');
  const [method,setMethod]=useState('PayPal');

  const handleDonate=e=>{
    e.preventDefault();
    axios.post('http://localhost:5000/donations',{name,amount,method})
      .then(()=>alert('تم التبرع بنجاح!'));
  }

  return (
    <section className="donations">
      <h2>تبرع الآن</h2>
      <form onSubmit={handleDonate}>
        <input placeholder="اسمك" value={name} onChange={e=>setName(e.target.value)} required/>
        <input type="number" placeholder="المبلغ" value={amount} onChange={e=>setAmount(e.target.value)} required/>
        <select value={method} onChange={e=>setMethod(e.target.value)}>
          <option>PayPal</option>
          <option>Stripe</option>
          <option>M-PESA</option>
        </select>
        <button type="submit">تبرع</button>
      </form>
    </section>
  );
}

export default Donations;
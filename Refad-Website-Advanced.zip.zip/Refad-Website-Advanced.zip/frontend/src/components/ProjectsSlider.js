import React, { useState, useEffect } from 'react';
import axios from 'axios';

function ProjectsSlider() {
  const [projects, setProjects] = useState([]);
  useEffect(()=>{
    axios.get('http://localhost:5000/admin/projects')
      .then(res=>setProjects(res.data));
  }, []);
  return (
    <section className="projects">
      <h2>مشاريعنا</h2>
      <div className="slider">
        {projects.map(p=>
          <div key={p._id} className="card">
            <img src={`http://localhost:5000${p.image}`} alt={p.title} />
            <h3>{p.title}</h3>
            <p>{p.description}</p>
          </div>
        )}
      </div>
    </section>
  );
}

export default ProjectsSlider;
import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Hero from './components/Hero';
import ProjectsSlider from './components/ProjectsSlider';
import Donations from './components/Donations';
import AdminPanel from './components/AdminPanel';
import './styles/main.css';

function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={
          <div>
            <Hero />
            <ProjectsSlider />
            <Donations />
          </div>
        }/>
        <Route path="/admin" element={<AdminPanel />}/>
      </Routes>
    </Router>
  );
}

export default App;
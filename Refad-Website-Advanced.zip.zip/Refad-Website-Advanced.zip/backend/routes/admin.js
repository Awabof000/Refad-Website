const express = require('express');
const router = express.Router();
const bcrypt = require('bcrypt');
const Admin = require('../models/Admin');
const Project = require('../models/Project');
const Team = require('../models/Team');
const multer = require('multer');

const storage = multer.diskStorage({
  destination: function(req, file, cb){ cb(null, 'uploads/'); },
  filename: function(req, file, cb){ cb(null, Date.now() + '-' + file.originalname); }
});
const upload = multer({ storage });

// Admin login
router.post('/login', async (req,res)=>{
  const { username, password } = req.body;
  const admin = await Admin.findOne({ username });
  if(admin && await bcrypt.compare(password, admin.password)){
    req.session.loggedIn = true;
    res.json({ success:true });
  } else res.status(401).json({ success:false, message:'كلمة السر خاطئة!' });
});

// Add project
router.post('/add-project', upload.single('image'), async (req,res)=>{
  if(!req.session.loggedIn) return res.status(401).json({message:'Unauthorized'});
  const { title, description } = req.body;
  const image = req.file ? '/uploads/' + req.file.filename : '';
  const project = new Project({ title, description, image });
  await project.save();
  res.json({ success:true, project });
});

// Add team member
router.post('/add-team', upload.single('photo'), async (req,res)=>{
  if(!req.session.loggedIn) return res.status(401).json({message:'Unauthorized'});
  const { name, role } = req.body;
  const photo = req.file ? '/uploads/' + req.file.filename : '';
  const member = new Team({ name, role, photo });
  await member.save();
  res.json({ success:true, member });
});

module.exports = router;
const express = require('express');
const router = express.Router();
const Donation = require('../models/Donation');

router.post('/', async (req,res)=>{
  const { name, amount, method } = req.body;
  const donation = new Donation({ name, amount, method });
  await donation.save();
  res.json({ success:true });
});

module.exports = router;
const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const DonationSchema = new Schema({
  name: String,
  amount: Number,
  method: String
});

module.exports = mongoose.model('Donation', DonationSchema);
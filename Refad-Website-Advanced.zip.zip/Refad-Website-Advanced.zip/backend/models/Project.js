const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const ProjectSchema = new Schema({
  title: String,
  description: String,
  image: String
});

module.exports = mongoose.model('Project', ProjectSchema);